                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1460354
VULCAN 400 - Large Sized Cartesian 3d Printer by makkusu is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

(WORK IN PROGRESS) 
The Vulcan 400, a modular 3D Printer designed for printing large objects. Objects as large as 400 x 400 x 210 approximately (Larger build size is possible). Z-axis assembly is modular allowing user to use a range of different build plate sizes. Any extruder system can be attached using a suitable mounting part which connects to the x-axis connector plate. This printer could be also used as a light duty cnc router. (More will be added also)

!! Actual Build Size: 430mm x 366mm x 210mm !!
!! Non Standard thin walled bearings used          !!

Update (21/08/16)
If your looking for the bearings to fit this printer robotdigg.com has them for good price;
http://www.robotdigg.com/product/717/KH0824PP+KH1026PP+or+KH1228PP+Linear+Bearing
http://www.robotdigg.com/product/718/KH1630PP+linear+bearing


Full solidworks model download:
https://www.dropbox.com/s/rlyarvuqakedivf/VULCAN%20400.zip?dl=0

https://www.youtube.com/watch?v=ZcC7l9IH_Dw

Bom

Belt
GT2 10m

Pulley
GT2 20 Tooth 5mm Bore 3x

Bearings
Bearing - (16mm Outer Dia - 5mm Inner Dia - 5mm Width) x6

Steppers
Standard Nema 17 5x

Leadscrew + Nut
ACME TR8*1 + Standard copper flange nut (4 hole) 2x

Endstop
Mechanical Endstops 3x

Extruder System
Any Extruder System can be attached using a suitable bracket

Nuts (Add 4x to Each to Insure there is enough)					
Slotted block B-type slot 8 Threaded Plate M8		22x			
T-nut heavy duty steel B-Type slot 6           M5	        16x		
M3 NUT		                                                                62x			
M5 NUT		                                                                90x			
										
Bolts (Add 2x to Each to Insure there is enough)						
M3 Socket Button Head	Length-10mm 	 20x			
M3 Socket Button Head	Length-15mm	 8x		
M3 Socket Button Head	Length-20mm	 16x		
M3 Socket Button Head  Length-25mm	 8x		
	
					
M5 Socket Button Head	Length-10mm	20x		
M5 Socket Button Head	Length-20mm	4x		
M5 Socket Button Head	Length-25mm	17x			
M5 Socket Button Head	Length-30mm	4x		
M5 Socket Button Head	Length-50mm	24x		
M5 Socket Button Head	Length-45mm	8x		
					
M8 Socket Button Head	Length-20mm	22x	

WASHER	 (Add 5x to Each to Insure there is enough)				
M3 Washer			62x	
M5 Washer			90x		
M8 Washer			24x		
									
					
3D Printed Parts						
motor mount		                                   2x			
motor mount b v2		                           2x			
shaft mount		                                   2x			
shaft mount b v2		                           2x			
y carraige motor mount		                   1x			
y carraige pulley mount		                   1x			
y carraige linear bearing clamp                  2x			
belt clamp		                                   4x		
x carraige mount v2		                           4x			
x carraige extruder mount	                   1x			
x carraige nut spacer		                   3x			
x endstop mount		                           1x		
upper support linear shaft	                   2x			
build plate mount		                           2x			
linear bearing + trapezoidal nut mount	   2x		
trapezoidal mount		                           2x			
lower support linear shaft		           2x			
estrusion bracket		                           4x			
x carraige belt mount		                   1x			
x carraige belt clamp		                   2x
Pulley                                                         3x

Aluminium Extrusion				
30 X 30 Slot 8 B type	660mm	4x		
30 X 30 Slot 8 B type	600mm	8x		
20 X 20 Slot 6 B type	500mm	2x		
20 X 20 Slot 6 B type	530mm	2x		
				
Linear Shaft			
12mm Dia Shaft	Length-600mm	2x	
16mm Dia Shaft	Length-600mm	2x		
16mm Dia Shaft	Length-400mm	2x		
					
Linear Bearing			
EP ISO Metric Closed Linear Ball Bearing Dia- 12mm 4x  (PBC-Linear)		
EP ISO Metric Closed Linear Ball Bearing Dia- 16mm 8x  (PBC-Linear)	
				
Profile Bracket				
Bracket 30        B Type Slot 8		20x	(With Fasteners)	
Bracket 20x40  B Type Slot 5		4x	(With Fasteners)