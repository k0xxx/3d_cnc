                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2838187
DIY 3D PRINTER with 6MM rod & T8 lead screw by electricdiylab is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Get cost effective stepper motors from Stepperonline  https://www.omc-stepperonline.com/?tracking=sharma  

Hello guys I have made this cheap 3D printer at home, I already have a 3D printer but I want to make my own 
So i design each and every part of this printer as per my need and build my own 3D Printer
Please note this before printing !!

The total printing time for all parts are approx 30 hour PLA 1.75
I have used 6MM Smooth rod & T8 lead screw with NEMA 17 Motor 42x42x34mm 4 Wires and GT2 timming belt 


Material I Used
3D printer electronics kit :- https://amzn.to/2pB685v
6MM Smooth rod :- https://amzn.to/2pAWizG
T8 Threaded rod :-  https://amzn.to/2pAEC83
Stepper motor :-    https://goo.gl/w9hHG3
Timing belt :- https://amzn.to/2pB4Wz3
Pulley :- https://amzn.to/2G6OIUG
Idler pulley :- https://amzn.to/2pAw94N
Hot end :- https://amzn.to/2G3exsI
Extruder :- https://amzn.to/2GgA00F
SMPS :-  https://amzn.to/2pAQ8QS
20 x 20 aluminium frame


Marlin Firmware :-
https://github.com/MarlinFirmware/Marlin/archive/1.1.x.zip

Pronterface :-
http://kliment.kapsi.fi/printrun/



visit for more
http://electricdiylab.com/

FB page :- https://www.facebook.com/InnovativeMr/
https://youtu.be/SGy_qPNHek4



# Print Settings

Printer Brand: TEVO
Printer: Tarantula
Rafts: No
Supports: Yes
Resolution: 0.15
Infill: 60

Notes: 
NOZZEL - 205
BED        -  0